% Assignment 0
% Name: Viren Velacheri, EID: vv6898
% Slip days: 0

% Simple Functions Descriptions

% I = eye(10) - This creates a 10 by 10 Identity matrix

% A = [zeros(2, 2), rand(2,2)]; a = A(:,2); - A 2 by 2 matrix of 0s and a 2
% by 2 matrix with random numbers on open interval (0,1) are concatenated
% together to form a 2 by 4 matrix. Variable a is then set to the second
% column of this new matrix which is always just 0s

% b = reshape(ones(10,1)*ones(1,10), [1,100]) - Essentially reshapes 10 by
% 10 matrix of ones into a row vector of 100 1s

%  a = sort(rand(1,100)); b = a([end:-1:1]) - a is a row vector with 100
%  random numbers, ranging from 0 (exclusive) to 1 (exclusive), sorted from
%  least to greatest or left to right in vector. variable b is row vector
%  with these same elements, but in reversed order where instead of 
% ascending from left to right, they are descending.

% [u,v,w] = svd(rand(3,3)) - the 3 by 3 matrix with random numbers ranging
% from 0 (exclusively) to 1 (exclusively) is factorized such that u is an
% orthogonal 3 by 3 matrix (U matrix), v is ∑ or basically a diagonalized
% matrix with singular values across diagonal, and the w is (V^T matrix) or
% another orthogonal matrix. Basically the 3 by 3 matrix with random 
% numbers equals u * v * w' where the singular values are stored in v.

% The Short Programming Example

picture = 'Tom_Brady.jpg';
% Just did this to change default "figure 1" heading to something 
% more descriptive
figure("name", "Examples of Image Transformations","NumberTitle", "off");
color_image = imread(picture);
subplot(1,7,1);
imshow(color_image)
title("Color Image");
% where grayscale image transformation takes place to color image
grayscale_image = converttogray(color_image);
subplot(1,7,2);
imshow(grayscale_image)
title("Grayscale Image");

% where negative image transformation takes place to grayscale image
negative_image = converttonegative(grayscale_image);
subplot(1,7,3);
imshow(negative_image)
title("Negative Image");

% where left-to-right flip of negative image takes place
flipped_image = flipimage(negative_image);
subplot(1,7,4);
imshow(flipped_image)
title("Left-To-Right Flipped Image");

% red and green channels flip takes place with color image
grb_image = flipchannels(color_image);
subplot(1,7,5);
imshow(grb_image)
title("Channels Swapped");

% random value addition takes place with grayscale image
random_add_image = randomvalueadd(grayscale_image);
subplot(1,7,6);
imshow(random_add_image)
title("Addition of Random Value");

% plot of pixels with intensities at 128 in grayscale image. Rest of
% pixels that don't have intensities set at 128 are white.
% Interesting that the pixels with 128 intensities highlighted as black
% appear to outline the main figure. Very interesting and I am sure this
% a preview of things to come. So excited!
plotted_image = plotpixels(grayscale_image);
subplot(1,7,7);
imshow(plotted_image)
title("128 Intensity Pixels");







