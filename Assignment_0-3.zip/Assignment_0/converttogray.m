% Input is a color image and output is the grayscale image
function gray = converttogray(I)
% rgb2gray function does the conversion of color image to grayscale
gray = rgb2gray(I); 
end