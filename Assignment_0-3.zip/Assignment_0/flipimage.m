% This function fips image from left to right. Input can be any image
% but in script where function is ran, input is the negative image. Output
% is the new left-to-right flipped image.
function mirror = flipimage(I)
% fliplr does left to right flip of image. Found it in matlab
% matlab documentation
mirror = fliplr(I);
end
