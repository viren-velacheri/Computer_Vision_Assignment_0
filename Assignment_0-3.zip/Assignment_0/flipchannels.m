% Swaps red and green channels of color image and reduces intensity of  
% new red channel by half. The output is this new image.
function swap = flipchannels(I)
redChannel = I(:, :,1);
greenChannel = I(:, :,2) * 0.5; % reduces intensity of green channel by 1/2
greenChannel = round(greenChannel); % just round up or down as needed
blueChannel = I(:, :, 3);
% new image generated with green and red channels swapped using below cat
% function which just concatenates them
swap = cat(3, greenChannel, redChannel, blueChannel);
end