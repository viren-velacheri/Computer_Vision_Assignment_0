% Takes in grayscale image as input and in the new image all but pixels 
% with intensities at 128 are set to 255 or white, while the pixels with
% intensities at 128 are set to black. The new image is the output
function plot = plotpixels(gray)
indices = gray ~= 128; % gets indices of values in matrix not 128
% the indices of values in matrix not 128 are set to 255 or white
gray(indices) = 255;
% gets indices of values in matrix that are 128
selected_indices = gray == 128;
gray(selected_indices) = 0; % selected pixels set to 0 or black.
plot = gray;
end