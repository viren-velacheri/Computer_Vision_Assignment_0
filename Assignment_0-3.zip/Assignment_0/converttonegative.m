% Takes in grayscale image and converts it to its "negative image" or 
% where the lightest values appear dark and vice versa.
function negative = converttonegative(I)
% expression below does the conversion where lightest values become dark
% and vice versa. Do casting at end as well.
negative = 255 - I;
negative = uint8(negative);
end