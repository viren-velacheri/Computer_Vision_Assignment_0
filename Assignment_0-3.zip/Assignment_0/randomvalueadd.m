% Takes grayscale image and adds a random value to all pixels.
% Image is clipped off to where any value above 255 is set to 255 or 
% any value below 0 is set to 0.
function random = randomvalueadd(gray)
randvalue = randi(256) - 1; % gets a random value between [0, 255]
% adds random value to all values in grayscale image matrix
random = gray + randvalue; 
% do type casting to uint8 just in case
random = uint8(random);
% find indices of values that are greater than 255 after addition
indices = random > 255;
% found indices are set/clipped to 255
random(indices) = 255;
% clipping is done for values below 0 as well. there should be no values 
% since all values should be 0 and above from start and since we are 
% just adding a positive number, it will never be the case. Just added as 
% a precaution and for completeness.
indices2 = random < 0;
random(indices2) = 0;
end
